﻿LandSurv.ai Civil 3D Connector v26.09.07.09

Direct NETLOAD bundle for manual installation.

1. Right-click the downloaded zip and choose Unblock (or run Unblock-File on the zip).
2. Extract all files to a folder.
3. In Civil 3D, type NETLOAD and select LandsurvConnector.dll.
4. If Civil 3D shows an old version, close Civil 3D completely, delete any old copy, and NETLOAD the new DLL again.

This archive is built from the exact output of the current source tree and contains the current connector assembly.
